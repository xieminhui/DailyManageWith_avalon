module.exports = {
    views: {
        "": {
            template: require("./template/detail.html"),
            controller: require("./controller/detail")
        }
    }
}   