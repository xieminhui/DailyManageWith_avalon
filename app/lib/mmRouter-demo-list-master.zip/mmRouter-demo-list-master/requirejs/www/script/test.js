define(['avalon'], function() {
    window.nidayede = 2  
})