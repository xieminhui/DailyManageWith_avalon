requirejs(["./common"], function (argument) {
    requirejs(["pages/route"])
})