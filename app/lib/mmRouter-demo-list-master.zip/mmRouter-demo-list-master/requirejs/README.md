
*** requirejs 请执行 r.js -o build.js，支持打包后按需加载


*** 用gulp集成 请执行 gulp build，配置在gulpfile.js内