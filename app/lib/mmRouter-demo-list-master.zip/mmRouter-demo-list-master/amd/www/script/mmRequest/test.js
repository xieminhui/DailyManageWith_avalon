function change() {
	avalon.vmodels.test.time = +new Date()
	avalon.vmodels.test.jsonData = [{name: "Smith"}, {name: "doubi"}]
}